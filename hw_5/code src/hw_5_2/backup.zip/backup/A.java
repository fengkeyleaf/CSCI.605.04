/**
 * This file is used by B.java
 */

package hw_5_2;

public class A
{
    protected int value = 1;

    public A() { this.methodOne(); }

    public void methodOne() { System.out.print("A"); }
}
