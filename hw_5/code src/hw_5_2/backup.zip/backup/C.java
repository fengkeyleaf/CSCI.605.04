package hw_5_2;

public class C extends B{
    protected int value = 2;

    public C() { System.out.print("&"); }

    public void cMethod () {
        System.out.println("\nc exclusive");
    }

    public void methodOne() {
        super.methodOne();
        System.out.print("C");
    }

    public static void main ( String [] args ) {
        A obj = new C();
        obj.methodOne();
//        //downcasting
//        B obj2 = (B) obj;
//        obj2.bMethod();

//        //field hiding
//        System.out.println(obj.value);
//        System.out.println(obj2.value);

    }

}
