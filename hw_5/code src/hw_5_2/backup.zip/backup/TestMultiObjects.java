package hw_5_2;

public class TestMultiObjects {

}
